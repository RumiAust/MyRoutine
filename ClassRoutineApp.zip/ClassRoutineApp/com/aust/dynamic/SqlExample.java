package com.aust.dynamic;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import java.util.Calendar;

public class SqlExample extends Activity implements OnClickListener {
    static final int DATE_DIALOG_ID = 100;
    static final int TIME_DIALOG_ID = 999;
    private Button buttonDate;
    private Button buttonTime;
    private OnDateSetListener datePickerListener = new C00421();
    private DatePicker date_picker;
    private int day;
    Button deleteButton;
    private int hour;
    private int minute;
    private int month;
    String name;
    String sRow;
    String sRow1;
    Button saveButton;
    TextView subject;
    private TimePicker timePicker;
    private OnTimeSetListener timePickerListener = new C00432();
    TextView tvRowId;
    Button updateButton;
    private int year;

    class C00421 implements OnDateSetListener {
        C00421() {
        }

        public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
            SqlExample.this.year = selectedYear;
            SqlExample.this.month = selectedMonth;
            SqlExample.this.day = selectedDay;
            SqlExample.this.date_picker.init(SqlExample.this.year, SqlExample.this.month, SqlExample.this.day, null);
        }
    }

    class C00432 implements OnTimeSetListener {
        C00432() {
        }

        public void onTimeSet(TimePicker view, int selectedHour, int selectedMinute) {
            SqlExample.this.hour = selectedHour;
            SqlExample.this.minute = selectedMinute;
            SqlExample.this.timePicker.setCurrentHour(Integer.valueOf(SqlExample.this.hour));
            SqlExample.this.timePicker.setCurrentMinute(Integer.valueOf(SqlExample.this.minute));
        }
    }

    class C00443 implements OnClickListener {
        C00443() {
        }

        public void onClick(View v) {
            SqlExample.this.showDialog(SqlExample.DATE_DIALOG_ID);
        }
    }

    class C00454 implements OnClickListener {
        C00454() {
        }

        public void onClick(View v) {
            SqlExample.this.showDialog(SqlExample.TIME_DIALOG_ID);
        }
    }

    public void onClick(android.view.View r30) {
        /* JADX: method processing error */
/*
Error: java.util.NoSuchElementException
	at java.util.HashMap$HashIterator.nextNode(HashMap.java:1431)
	at java.util.HashMap$KeyIterator.next(HashMap.java:1453)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.applyRemove(BlockFinallyExtract.java:535)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.extractFinally(BlockFinallyExtract.java:175)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.processExceptionHandler(BlockFinallyExtract.java:79)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.visit(BlockFinallyExtract.java:51)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r29 = this;
        r7 = r30.getId();
        switch(r7) {
            case 2131230733: goto L_0x0008;
            case 2131230734: goto L_0x0262;
            case 2131230735: goto L_0x04cc;
            default: goto L_0x0007;
        };
    L_0x0007:
        return;
    L_0x0008:
        r28 = 1;
        r0 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r7 = r0.subject;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r7 = r7.getText();	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r7 = r7.toString();	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0.name = r7;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r3 = new com.aust.dynamic.HotOrNot;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r3.<init>(r0);	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r3.open();	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r4 = r0.name;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r5 = r0.day;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r6 = r0.month;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r7 = r0.year;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r8 = r0.hour;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r9 = r0.minute;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r3.createEntry(r4, r5, r6, r7, r8, r9);	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r3.close();	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        if (r28 == 0) goto L_0x0007;
    L_0x0044:
        r7 = "notification";
        r0 = r29;
        r22 = r0.getSystemService(r7);
        r22 = (android.app.NotificationManager) r22;
        r23 = new android.app.Notification;
        r7 = 17301623; // 0x1080077 float:2.4979588E-38 double:8.5481375E-317;
        r8 = "Confirmation Notification";
        r9 = java.lang.System.currentTimeMillis();
        r0 = r23;
        r0.<init>(r7, r8, r9);
        r13 = r29;
        r26 = "Your information has been saved to DataBase Successfully";
        r7 = new java.lang.StringBuilder;
        r7.<init>();
        r0 = r29;
        r8 = r0.name;
        r7 = r7.append(r8);
        r8 = " ";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.day;
        r7 = r7.append(r8);
        r8 = "/";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.month;
        r7 = r7.append(r8);
        r8 = "/";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.year;
        r7 = r7.append(r8);
        r8 = "  ";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.hour;
        r7 = r7.append(r8);
        r8 = ":";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.minute;
        r7 = r7.append(r8);
        r8 = " Pm";
        r7 = r7.append(r8);
        r8 = " is listed in lisView";
        r7 = r7.append(r8);
        r15 = r7.toString();
        r19 = new android.content.Intent;
        r7 = com.aust.dynamic.MainActivity.class;
        r0 = r19;
        r0.<init>(r13, r7);
        r7 = 0;
        r8 = 0;
        r0 = r19;
        r24 = android.app.PendingIntent.getActivity(r13, r7, r0, r8);
        r0 = r23;
        r1 = r26;
        r2 = r24;
        r0.setLatestEventInfo(r13, r1, r15, r2);
        r7 = 2;
        r0 = r22;
        r1 = r23;
        r0.notify(r7, r1);
        goto L_0x0007;
    L_0x00e9:
        r16 = move-exception;
        r28 = 0;
        r17 = r16.toString();	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r14 = new android.app.Dialog;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r14.<init>(r0);	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r7 = "Error!!!!";	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r14.setTitle(r7);	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r27 = new android.widget.TextView;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r27;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r1 = r29;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0.<init>(r1);	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r27;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r1 = r17;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0.setText(r1);	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r0 = r27;	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r14.setContentView(r0);	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        r14.show();	 Catch:{ Exception -> 0x00e9, all -> 0x01bb }
        if (r28 == 0) goto L_0x0007;
    L_0x0116:
        r7 = "notification";
        r0 = r29;
        r22 = r0.getSystemService(r7);
        r22 = (android.app.NotificationManager) r22;
        r23 = new android.app.Notification;
        r7 = 17301623; // 0x1080077 float:2.4979588E-38 double:8.5481375E-317;
        r8 = "Confirmation Notification";
        r9 = java.lang.System.currentTimeMillis();
        r0 = r23;
        r0.<init>(r7, r8, r9);
        r13 = r29;
        r26 = "Your information has been saved to DataBase Successfully";
        r7 = new java.lang.StringBuilder;
        r7.<init>();
        r0 = r29;
        r8 = r0.name;
        r7 = r7.append(r8);
        r8 = " ";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.day;
        r7 = r7.append(r8);
        r8 = "/";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.month;
        r7 = r7.append(r8);
        r8 = "/";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.year;
        r7 = r7.append(r8);
        r8 = "  ";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.hour;
        r7 = r7.append(r8);
        r8 = ":";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.minute;
        r7 = r7.append(r8);
        r8 = " Pm";
        r7 = r7.append(r8);
        r8 = " is listed in lisView";
        r7 = r7.append(r8);
        r15 = r7.toString();
        r19 = new android.content.Intent;
        r7 = com.aust.dynamic.MainActivity.class;
        r0 = r19;
        r0.<init>(r13, r7);
        r7 = 0;
        r8 = 0;
        r0 = r19;
        r24 = android.app.PendingIntent.getActivity(r13, r7, r0, r8);
        r0 = r23;
        r1 = r26;
        r2 = r24;
        r0.setLatestEventInfo(r13, r1, r15, r2);
        r7 = 2;
        r0 = r22;
        r1 = r23;
        r0.notify(r7, r1);
        goto L_0x0007;
    L_0x01bb:
        r7 = move-exception;
        if (r28 == 0) goto L_0x0261;
    L_0x01be:
        r8 = "notification";
        r0 = r29;
        r22 = r0.getSystemService(r8);
        r22 = (android.app.NotificationManager) r22;
        r23 = new android.app.Notification;
        r8 = 17301623; // 0x1080077 float:2.4979588E-38 double:8.5481375E-317;
        r9 = "Confirmation Notification";
        r10 = java.lang.System.currentTimeMillis();
        r0 = r23;
        r0.<init>(r8, r9, r10);
        r13 = r29;
        r26 = "Your information has been saved to DataBase Successfully";
        r8 = new java.lang.StringBuilder;
        r8.<init>();
        r0 = r29;
        r9 = r0.name;
        r8 = r8.append(r9);
        r9 = " ";
        r8 = r8.append(r9);
        r0 = r29;
        r9 = r0.day;
        r8 = r8.append(r9);
        r9 = "/";
        r8 = r8.append(r9);
        r0 = r29;
        r9 = r0.month;
        r8 = r8.append(r9);
        r9 = "/";
        r8 = r8.append(r9);
        r0 = r29;
        r9 = r0.year;
        r8 = r8.append(r9);
        r9 = "  ";
        r8 = r8.append(r9);
        r0 = r29;
        r9 = r0.hour;
        r8 = r8.append(r9);
        r9 = ":";
        r8 = r8.append(r9);
        r0 = r29;
        r9 = r0.minute;
        r8 = r8.append(r9);
        r9 = " Pm";
        r8 = r8.append(r9);
        r9 = " is listed in lisView";
        r8 = r8.append(r9);
        r15 = r8.toString();
        r19 = new android.content.Intent;
        r8 = com.aust.dynamic.MainActivity.class;
        r0 = r19;
        r0.<init>(r13, r8);
        r8 = 0;
        r9 = 0;
        r0 = r19;
        r24 = android.app.PendingIntent.getActivity(r13, r8, r0, r9);
        r0 = r23;
        r1 = r26;
        r2 = r24;
        r0.setLatestEventInfo(r13, r1, r15, r2);
        r8 = 2;
        r0 = r22;
        r1 = r23;
        r0.notify(r8, r1);
    L_0x0261:
        throw r7;
    L_0x0262:
        r28 = 1;
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r7 = r0.subject;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r7 = r7.getText();	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r7 = r7.toString();	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0.name = r7;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r7 = r0.tvRowId;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r7 = r7.getText();	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r25 = r7.toString();	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r5 = java.lang.Long.parseLong(r25);	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r4 = new com.aust.dynamic.HotOrNot;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r4.<init>(r0);	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r4.open();	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r7 = r0.name;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r8 = r0.day;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r9 = r0.month;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r10 = r0.year;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r11 = r0.hour;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r12 = r0.minute;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r4.updateEntry(r5, r7, r8, r9, r10, r11, r12);	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r4.close();	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        if (r28 == 0) goto L_0x0007;
    L_0x02ae:
        r7 = "notification";
        r0 = r29;
        r22 = r0.getSystemService(r7);
        r22 = (android.app.NotificationManager) r22;
        r23 = new android.app.Notification;
        r7 = 17301623; // 0x1080077 float:2.4979588E-38 double:8.5481375E-317;
        r8 = "Confirmation Notification";
        r9 = java.lang.System.currentTimeMillis();
        r0 = r23;
        r0.<init>(r7, r8, r9);
        r13 = r29;
        r26 = "Your DataBase has been updated Successfully";
        r7 = new java.lang.StringBuilder;
        r7.<init>();
        r0 = r29;
        r8 = r0.name;
        r7 = r7.append(r8);
        r8 = " at ";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.day;
        r7 = r7.append(r8);
        r8 = "/";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.month;
        r7 = r7.append(r8);
        r8 = "/";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.year;
        r7 = r7.append(r8);
        r8 = "  ";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.hour;
        r7 = r7.append(r8);
        r8 = ":";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.minute;
        r7 = r7.append(r8);
        r8 = " Pm";
        r7 = r7.append(r8);
        r8 = " is listed in lisView";
        r7 = r7.append(r8);
        r15 = r7.toString();
        r19 = new android.content.Intent;
        r7 = com.aust.dynamic.MainActivity.class;
        r0 = r19;
        r0.<init>(r13, r7);
        r7 = 0;
        r8 = 0;
        r0 = r19;
        r24 = android.app.PendingIntent.getActivity(r13, r7, r0, r8);
        r0 = r23;
        r1 = r26;
        r2 = r24;
        r0.setLatestEventInfo(r13, r1, r15, r2);
        r7 = 1;
        r0 = r22;
        r1 = r23;
        r0.notify(r7, r1);
        goto L_0x0007;
    L_0x0353:
        r16 = move-exception;
        r28 = 0;
        r17 = r16.toString();	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r14 = new android.app.Dialog;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r14.<init>(r0);	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r7 = "Error!!!!";	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r14.setTitle(r7);	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r27 = new android.widget.TextView;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r27;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r1 = r29;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0.<init>(r1);	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r27;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r1 = r17;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0.setText(r1);	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r0 = r27;	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r14.setContentView(r0);	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        r14.show();	 Catch:{ Exception -> 0x0353, all -> 0x0425 }
        if (r28 == 0) goto L_0x0007;
    L_0x0380:
        r7 = "notification";
        r0 = r29;
        r22 = r0.getSystemService(r7);
        r22 = (android.app.NotificationManager) r22;
        r23 = new android.app.Notification;
        r7 = 17301623; // 0x1080077 float:2.4979588E-38 double:8.5481375E-317;
        r8 = "Confirmation Notification";
        r9 = java.lang.System.currentTimeMillis();
        r0 = r23;
        r0.<init>(r7, r8, r9);
        r13 = r29;
        r26 = "Your DataBase has been updated Successfully";
        r7 = new java.lang.StringBuilder;
        r7.<init>();
        r0 = r29;
        r8 = r0.name;
        r7 = r7.append(r8);
        r8 = " at ";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.day;
        r7 = r7.append(r8);
        r8 = "/";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.month;
        r7 = r7.append(r8);
        r8 = "/";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.year;
        r7 = r7.append(r8);
        r8 = "  ";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.hour;
        r7 = r7.append(r8);
        r8 = ":";
        r7 = r7.append(r8);
        r0 = r29;
        r8 = r0.minute;
        r7 = r7.append(r8);
        r8 = " Pm";
        r7 = r7.append(r8);
        r8 = " is listed in lisView";
        r7 = r7.append(r8);
        r15 = r7.toString();
        r19 = new android.content.Intent;
        r7 = com.aust.dynamic.MainActivity.class;
        r0 = r19;
        r0.<init>(r13, r7);
        r7 = 0;
        r8 = 0;
        r0 = r19;
        r24 = android.app.PendingIntent.getActivity(r13, r7, r0, r8);
        r0 = r23;
        r1 = r26;
        r2 = r24;
        r0.setLatestEventInfo(r13, r1, r15, r2);
        r7 = 1;
        r0 = r22;
        r1 = r23;
        r0.notify(r7, r1);
        goto L_0x0007;
    L_0x0425:
        r7 = move-exception;
        if (r28 == 0) goto L_0x04cb;
    L_0x0428:
        r8 = "notification";
        r0 = r29;
        r22 = r0.getSystemService(r8);
        r22 = (android.app.NotificationManager) r22;
        r23 = new android.app.Notification;
        r8 = 17301623; // 0x1080077 float:2.4979588E-38 double:8.5481375E-317;
        r9 = "Confirmation Notification";
        r10 = java.lang.System.currentTimeMillis();
        r0 = r23;
        r0.<init>(r8, r9, r10);
        r13 = r29;
        r26 = "Your DataBase has been updated Successfully";
        r8 = new java.lang.StringBuilder;
        r8.<init>();
        r0 = r29;
        r9 = r0.name;
        r8 = r8.append(r9);
        r9 = " at ";
        r8 = r8.append(r9);
        r0 = r29;
        r9 = r0.day;
        r8 = r8.append(r9);
        r9 = "/";
        r8 = r8.append(r9);
        r0 = r29;
        r9 = r0.month;
        r8 = r8.append(r9);
        r9 = "/";
        r8 = r8.append(r9);
        r0 = r29;
        r9 = r0.year;
        r8 = r8.append(r9);
        r9 = "  ";
        r8 = r8.append(r9);
        r0 = r29;
        r9 = r0.hour;
        r8 = r8.append(r9);
        r9 = ":";
        r8 = r8.append(r9);
        r0 = r29;
        r9 = r0.minute;
        r8 = r8.append(r9);
        r9 = " Pm";
        r8 = r8.append(r9);
        r9 = " is listed in lisView";
        r8 = r8.append(r9);
        r15 = r8.toString();
        r19 = new android.content.Intent;
        r8 = com.aust.dynamic.MainActivity.class;
        r0 = r19;
        r0.<init>(r13, r8);
        r8 = 0;
        r9 = 0;
        r0 = r19;
        r24 = android.app.PendingIntent.getActivity(r13, r8, r0, r9);
        r0 = r23;
        r1 = r26;
        r2 = r24;
        r0.setLatestEventInfo(r13, r1, r15, r2);
        r8 = 1;
        r0 = r22;
        r1 = r23;
        r0.notify(r8, r1);
    L_0x04cb:
        throw r7;
    L_0x04cc:
        r28 = 1;
        r0 = r29;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r7 = r0.tvRowId;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r7 = r7.getText();	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r7 = r7.toString();	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0 = r29;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0.sRow1 = r7;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0 = r29;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r7 = r0.sRow1;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r20 = java.lang.Long.parseLong(r7);	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r18 = new com.aust.dynamic.HotOrNot;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0 = r18;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r1 = r29;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0.<init>(r1);	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r18.open();	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0 = r18;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r1 = r20;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0.updateEntry(r1);	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r18.close();	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        if (r28 == 0) goto L_0x0007;
    L_0x04fe:
        r0 = r29;
        r7 = r0.tvRowId;
        r7 = r7.getText();
        r7 = r7.toString();
        r0 = r29;
        r0.sRow1 = r7;
        r7 = "notification";
        r0 = r29;
        r22 = r0.getSystemService(r7);
        r22 = (android.app.NotificationManager) r22;
        r23 = new android.app.Notification;
        r7 = 17301623; // 0x1080077 float:2.4979588E-38 double:8.5481375E-317;
        r8 = "Confirmation Notification";
        r9 = java.lang.System.currentTimeMillis();
        r0 = r23;
        r0.<init>(r7, r8, r9);
        r13 = r29;
        r26 = "Your DataBase  has been deleted Successsfully";
        r7 = new java.lang.StringBuilder;
        r8 = "Quiz Id: ";
        r7.<init>(r8);
        r0 = r29;
        r8 = r0.sRow1;
        r7 = r7.append(r8);
        r8 = " is deleted permanently";
        r7 = r7.append(r8);
        r15 = r7.toString();
        r19 = new android.content.Intent;
        r7 = com.aust.dynamic.MainActivity.class;
        r0 = r19;
        r0.<init>(r13, r7);
        r7 = 0;
        r8 = 0;
        r0 = r19;
        r24 = android.app.PendingIntent.getActivity(r13, r7, r0, r8);
        r0 = r23;
        r1 = r26;
        r2 = r24;
        r0.setLatestEventInfo(r13, r1, r15, r2);
        r7 = 0;
        r0 = r22;
        r1 = r23;
        r0.notify(r7, r1);
        goto L_0x0007;
    L_0x0569:
        r16 = move-exception;
        r28 = 0;
        r17 = r16.toString();	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r14 = new android.app.Dialog;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0 = r29;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r14.<init>(r0);	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r7 = "Error!!!!";	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r14.setTitle(r7);	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r27 = new android.widget.TextView;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0 = r27;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r1 = r29;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0.<init>(r1);	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0 = r27;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r1 = r17;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0.setText(r1);	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r0 = r27;	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r14.setContentView(r0);	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        r14.show();	 Catch:{ Exception -> 0x0569, all -> 0x0601 }
        if (r28 == 0) goto L_0x0007;
    L_0x0596:
        r0 = r29;
        r7 = r0.tvRowId;
        r7 = r7.getText();
        r7 = r7.toString();
        r0 = r29;
        r0.sRow1 = r7;
        r7 = "notification";
        r0 = r29;
        r22 = r0.getSystemService(r7);
        r22 = (android.app.NotificationManager) r22;
        r23 = new android.app.Notification;
        r7 = 17301623; // 0x1080077 float:2.4979588E-38 double:8.5481375E-317;
        r8 = "Confirmation Notification";
        r9 = java.lang.System.currentTimeMillis();
        r0 = r23;
        r0.<init>(r7, r8, r9);
        r13 = r29;
        r26 = "Your DataBase  has been deleted Successsfully";
        r7 = new java.lang.StringBuilder;
        r8 = "Quiz Id: ";
        r7.<init>(r8);
        r0 = r29;
        r8 = r0.sRow1;
        r7 = r7.append(r8);
        r8 = " is deleted permanently";
        r7 = r7.append(r8);
        r15 = r7.toString();
        r19 = new android.content.Intent;
        r7 = com.aust.dynamic.MainActivity.class;
        r0 = r19;
        r0.<init>(r13, r7);
        r7 = 0;
        r8 = 0;
        r0 = r19;
        r24 = android.app.PendingIntent.getActivity(r13, r7, r0, r8);
        r0 = r23;
        r1 = r26;
        r2 = r24;
        r0.setLatestEventInfo(r13, r1, r15, r2);
        r7 = 0;
        r0 = r22;
        r1 = r23;
        r0.notify(r7, r1);
        goto L_0x0007;
    L_0x0601:
        r7 = move-exception;
        if (r28 == 0) goto L_0x066d;
    L_0x0604:
        r0 = r29;
        r8 = r0.tvRowId;
        r8 = r8.getText();
        r8 = r8.toString();
        r0 = r29;
        r0.sRow1 = r8;
        r8 = "notification";
        r0 = r29;
        r22 = r0.getSystemService(r8);
        r22 = (android.app.NotificationManager) r22;
        r23 = new android.app.Notification;
        r8 = 17301623; // 0x1080077 float:2.4979588E-38 double:8.5481375E-317;
        r9 = "Confirmation Notification";
        r10 = java.lang.System.currentTimeMillis();
        r0 = r23;
        r0.<init>(r8, r9, r10);
        r13 = r29;
        r26 = "Your DataBase  has been deleted Successsfully";
        r8 = new java.lang.StringBuilder;
        r9 = "Quiz Id: ";
        r8.<init>(r9);
        r0 = r29;
        r9 = r0.sRow1;
        r8 = r8.append(r9);
        r9 = " is deleted permanently";
        r8 = r8.append(r9);
        r15 = r8.toString();
        r19 = new android.content.Intent;
        r8 = com.aust.dynamic.MainActivity.class;
        r0 = r19;
        r0.<init>(r13, r8);
        r8 = 0;
        r9 = 0;
        r0 = r19;
        r24 = android.app.PendingIntent.getActivity(r13, r8, r0, r9);
        r0 = r23;
        r1 = r26;
        r2 = r24;
        r0.setLatestEventInfo(r13, r1, r15, r2);
        r8 = 0;
        r0 = r22;
        r1 = r23;
        r0.notify(r8, r1);
    L_0x066d:
        throw r7;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.aust.dynamic.SqlExample.onClick(android.view.View):void");
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0040R.layout.sqlexample);
        this.saveButton = (Button) findViewById(C0040R.id.bSave);
        this.updateButton = (Button) findViewById(C0040R.id.bUpdate);
        this.deleteButton = (Button) findViewById(C0040R.id.bDelete);
        this.date_picker = (DatePicker) findViewById(C0040R.id.date_picker);
        this.timePicker = (TimePicker) findViewById(C0040R.id.timePicker);
        this.subject = (TextView) findViewById(C0040R.id.etSubject);
        this.tvRowId = (TextView) findViewById(C0040R.id.editText2);
        this.saveButton.setOnClickListener(this);
        this.updateButton.setOnClickListener(this);
        this.deleteButton.setOnClickListener(this);
        setCurrentDate();
        addButtonListenerDate();
        setCurrentTimeOnView();
        addButtonListenerTime();
    }

    public void setCurrentDate() {
        this.date_picker = (DatePicker) findViewById(C0040R.id.date_picker);
        Calendar calendar = Calendar.getInstance();
        this.year = calendar.get(1);
        this.month = calendar.get(2);
        this.day = calendar.get(5);
        this.date_picker.init(this.year, this.month, this.day, null);
    }

    public void addButtonListenerDate() {
        this.buttonDate = (Button) findViewById(C0040R.id.buttonDate);
        this.buttonDate.setOnClickListener(new C00443());
    }

    public void setCurrentTimeOnView() {
        this.timePicker = (TimePicker) findViewById(C0040R.id.timePicker);
        Calendar c = Calendar.getInstance();
        this.hour = c.get(11);
        this.minute = c.get(12);
        this.timePicker.setCurrentHour(Integer.valueOf(this.hour));
        this.timePicker.setCurrentMinute(Integer.valueOf(this.minute));
    }

    public void addButtonListenerTime() {
        this.buttonTime = (Button) findViewById(C0040R.id.buttonTime);
        this.buttonTime.setOnClickListener(new C00454());
    }

    private static String padding_str(int c) {
        if (c >= 10) {
            return String.valueOf(c);
        }
        return "0" + String.valueOf(c);
    }

    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_DIALOG_ID /*100*/:
                return new DatePickerDialog(this, this.datePickerListener, this.year, this.month, this.day);
            case TIME_DIALOG_ID /*999*/:
                return new TimePickerDialog(this, this.timePickerListener, this.hour, this.minute, false);
            default:
                return null;
        }
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}
