package com.aust.dynamic;

import android.app.Dialog;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;

public class TabMenu extends TabActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0040R.layout.tabmenu);
        Resources ressources = getResources();
        TabHost tabHost = getTabHost();
        getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0066FF")));
        TabSpec tabSpecEng = tabHost.newTabSpec("Groups").setIndicator("SECTION A").setContent(new Intent().setClass(this, MainActivity.class));
        TabSpec tabSpecMedical = tabHost.newTabSpec("Fixtures").setIndicator("SECTION B").setContent(new Intent().setClass(this, MainActivity2.class));
        tabHost.addTab(tabSpecEng);
        tabHost.addTab(tabSpecMedical);
        tabHost.setCurrentTab(0);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(C0040R.menu.cool_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case C0040R.id.addQuiz:
                startActivity(new Intent("com.aust.dynamic.SQLEXAMPLE"));
                break;
            case C0040R.id.viewQuiz:
                startActivity(new Intent("com.aust.dynamic.SQLVIEW"));
                break;
            case C0040R.id.about:
                Dialog d = new Dialog(this);
                TextView tv = new TextView(this);
                tv.setText("Md. Golam Muktadir Rume\nStudying CSE at Ahsanullah University of Science And Technology\nEmail:ruummee@gmail.com");
                d.setTitle("About Rume");
                d.setContentView(tv);
                d.show();
                break;
        }
        return false;
    }
}
