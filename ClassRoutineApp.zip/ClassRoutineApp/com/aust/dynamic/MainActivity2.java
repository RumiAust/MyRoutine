package com.aust.dynamic;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

@SuppressLint({"ShowToast"})
public class MainActivity2 extends Activity implements OnItemClickListener, OnClickListener {
    static final int MIN_DISTANCE = 100;
    ArrayAdapter<String> adapter;
    String[] array = new String[]{"Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    Button b1;
    Button b2;
    int counter = 0;
    TextView day;
    String dayLongName;
    ArrayList<String> list;
    ListView listview;
    int pos = 0;
    int f1x;
    private float x1;
    private float x2;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0040R.layout.activity_main);
        this.day = (TextView) findViewById(C0040R.id.day);
        String dayLongName = Calendar.getInstance().getDisplayName(7, 2, Locale.getDefault());
        if (dayLongName.contentEquals("Saturday")) {
            this.f1x = 0;
        } else if (dayLongName.contentEquals("Sunday")) {
            this.f1x = 1;
        } else if (dayLongName.contentEquals("Monday")) {
            this.f1x = 2;
        } else if (dayLongName.contentEquals("Tuesday")) {
            this.f1x = 3;
        } else if (dayLongName.contentEquals("Wednesday")) {
            this.f1x = 4;
        } else if (dayLongName.contentEquals("Thursday")) {
            this.f1x = 5;
        } else if (dayLongName.contentEquals("Friday")) {
            this.f1x = 6;
        }
        this.day.setText(dayLongName);
        this.listview = (ListView) findViewById(C0040R.id.listView);
        this.adapter = putvalue(this.f1x);
        this.listview.setAdapter(this.adapter);
        this.listview.setOnItemClickListener(this);
    }

    private ArrayAdapter<String> putvalue(int x) {
        String[] values0 = new String[]{"Data Structure Lab (B1) - 7B01 - 10:30 Am to 1 Pm", "Data Structure Lab (B2) - 7B05 - 1 Pm to 3:30 Pm"};
        String[] values1 = new String[]{"Data Structure - 7C06 - 10:30 Am to 11:20 Am", "Electronic Device - 7C06 - 11:20 Am to 12:10 Pm", "Math - 7C06 - 12:10 Pm to 1 Pm", "Electronic Device Lab (B1)- 1 Pm to 3:30 Pm", "DLD Lab (B2) - 7B04 - 1 Pm to 3:30 Pm"};
        String[] values2 = new String[]{"Society - 7A07 - 10:30 Am to 11:20 Am", "DLD - 7A07 - 11:20 Am to 1 Pm"};
        String[] values3 = new String[]{"DLD - 7A04 - 8 Am to 8:50 Am", "Electrical Device - 7A04 - 8:50 Am to 9:40 Am", "Data Structure - 7A04 - 9:40 Am to 10:30 Am", "DLD LAB (B1) - 7B04 - 10:30 Am to 1 Pm"};
        String[] values4 = new String[]{"Electronic Device Lab (B2)- 8 Am to 10:30 Am", "Data Structure - 7C07 - 10:30 Am to 11:20 Am", "Society - 7C07 - 11:20 Am to 1 pm"};
        String[] values5 = new String[]{"Software Lab (B1/B2) - 7B07 - 8 Am to 10:30 Am", "Math - 7C06 - 10:30 Am to 12:10 Pm", "Electronic Device - 7C06 - 12:10 Pm to  Pm"};
        String[] values6 = new String[]{"Enjoy Holiday!!!!!!"};
        if (x == 0) {
            this.list = new ArrayList();
            for (Object add : values0) {
                this.list.add(add);
            }
        } else if (x == 1) {
            this.list = new ArrayList();
            for (Object add2 : values1) {
                this.list.add(add2);
            }
        } else if (x == 2) {
            this.list = new ArrayList();
            for (Object add22 : values2) {
                this.list.add(add22);
            }
        }
        if (x == 3) {
            this.list = new ArrayList();
            for (Object add222 : values3) {
                this.list.add(add222);
            }
        } else if (x == 4) {
            this.list = new ArrayList();
            for (Object add2222 : values4) {
                this.list.add(add2222);
            }
        }
        if (x == 5) {
            this.day.setText(this.dayLongName);
            this.list = new ArrayList();
            for (Object add22222 : values5) {
                this.list.add(add22222);
            }
        } else if (x == 6) {
            this.list = new ArrayList();
            for (Object add222222 : values6) {
                this.list.add(add222222);
            }
        }
        this.day.setText(this.array[x]);
        this.day.setTextColor(-1);
        return new ArrayAdapter(this, 17367043, this.list);
    }

    public void onItemClick(AdapterView<?> adapterView, View v, int position, long arg3) {
    }

    public void onClick(View arg0) {
    }

    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case 0:
                this.x1 = event.getX();
                break;
            case 1:
                this.x2 = event.getX();
                if (Math.abs(this.x2 - this.x1) > 100.0f) {
                    if (this.x2 <= this.x1) {
                        this.list.clear();
                        this.f1x++;
                        if (this.f1x > 6) {
                            this.f1x = 0;
                        }
                        this.day.setText(this.f1x);
                        this.adapter = putvalue(this.f1x);
                        this.listview.setAdapter(this.adapter);
                        break;
                    }
                    this.list.clear();
                    this.f1x--;
                    if (this.f1x < 0) {
                        this.f1x = 6;
                    }
                    this.day.setText(this.f1x);
                    this.adapter = putvalue(this.f1x);
                    this.listview.setAdapter(this.adapter);
                    break;
                }
                break;
        }
        return true;
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}
