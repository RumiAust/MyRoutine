package com.aust.dynamic;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;

public class Splash extends Activity {

    class C00411 extends Thread {
        C00411() {
        }

        public void run() {
            try {
                C00411.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                Splash.this.startActivity(new Intent("com.javatechig.alarmservice.MainActivity"));
            }
        }
    }

    protected void onCreate(Bundle rumi) {
        super.onCreate(rumi);
        setContentView(C0040R.layout.splash);
        new C00411().start();
    }

    protected void onPause() {
        super.onPause();
        finish();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}
