package com.aust.dynamic;

public final class BuildConfig {
    public static final boolean DEBUG = true;
}
