package com.aust.dynamic;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

@SuppressLint({"ShowToast"})
public class MainActivity extends Activity implements OnItemClickListener, OnClickListener {
    static final int MIN_DISTANCE = 100;
    ArrayAdapter<String> adapter;
    String[] array = new String[]{"Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    Button b1;
    Button b2;
    int counter = 0;
    TextView day;
    String dayLongName;
    boolean ignoreDisabled = false;
    ArrayList<String> list;
    ListView listview;
    int f2x;
    private float x1;
    private float x2;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0040R.layout.activity_main);
        this.day = (TextView) findViewById(C0040R.id.day);
        String dayLongName = Calendar.getInstance().getDisplayName(7, 2, Locale.getDefault());
        if (dayLongName.contentEquals("Saturday")) {
            this.f2x = 0;
        } else if (dayLongName.contentEquals("Sunday")) {
            this.f2x = 1;
        } else if (dayLongName.contentEquals("Monday")) {
            this.f2x = 2;
        } else if (dayLongName.contentEquals("Tuesday")) {
            this.f2x = 3;
        } else if (dayLongName.contentEquals("Wednesday")) {
            this.f2x = 4;
        } else if (dayLongName.contentEquals("Thursday")) {
            this.f2x = 5;
        } else if (dayLongName.contentEquals("Friday")) {
            this.f2x = 6;
        }
        this.day.setText(dayLongName);
        this.listview = (ListView) findViewById(C0040R.id.listView);
        this.adapter = putvalue(this.f2x);
        this.listview.setAdapter(this.adapter);
        this.listview.setOnItemClickListener(this);
    }

    private ArrayAdapter<String> putvalue(int x) {
        String[] values0 = new String[]{"Electronic Device Lab (A1)- 3B06 -  8 Am to 10:30 Am", "DLD Lab (A2) - 7B04 - 8 Am to 10:30 Am", "DLD Lab (A1) - 7B04 - 10:30 Am to 1 Pm"};
        String[] values1 = new String[]{"DLD - 7A04 - 8 Am to 8:50 Am", "Electronic Device - 7A04 - 8:50 Am to 9:40 Am", "Data Structure - 7A04 - 9:40 Am to 10:30 Am"};
        String[] values2 = new String[]{"Electronic Device Lab (A2) - 8 Am to 10:30 Am", "Math - 7A03 - 10:30 Am to 11:20 Am", "Statistics - 7A03 - 11:20 Am to 12:10 Pm", "Electronic Device - 7A03 - 12:10 Pm to 1 Pm"};
        String[] values3 = new String[]{"Society - 7A03- 8 Am to 8:50 Am", "Data Structure - 7A03 - 8:50 Am to 9:40 Am", "Electrical Device - 7A03 -10:30 Am to 1 pm", "Data Structure Lab (A2) - 7B08 - 10:30 Am to 1 Pm"};
        String[] values4 = new String[]{"DLD - 7C06- 8 Am to 9:40 Am", "Data Structure - 7C06 - 9:40 Am to 10:30 Am", "Software Lab (A1/A2) - 7B08 - 10:30 Am to 1 pm"};
        String[] values5 = new String[]{"Data Structure Lab (A1) - 7B05 - 10:30 Am to 1 pm", "Society - 7A06 - 1 Pm to 2:40 Pm", "Math - 7A06 - 2:40 Pm to 3:30 Pm"};
        String[] values6 = new String[]{"Enjoy Holiday!!!!!!"};
        if (x == 0) {
            this.list = new ArrayList();
            for (Object add : values0) {
                this.list.add(add);
            }
        } else if (x == 1) {
            this.list = new ArrayList();
            for (Object add2 : values1) {
                this.list.add(add2);
            }
        } else if (x == 2) {
            this.list = new ArrayList();
            for (Object add22 : values2) {
                this.list.add(add22);
            }
        }
        if (x == 3) {
            this.list = new ArrayList();
            for (Object add222 : values3) {
                this.list.add(add222);
            }
        } else if (x == 4) {
            this.list = new ArrayList();
            for (Object add2222 : values4) {
                this.list.add(add2222);
            }
        }
        if (x == 5) {
            this.day.setText(this.dayLongName);
            this.list = new ArrayList();
            for (Object add22222 : values5) {
                this.list.add(add22222);
            }
        } else if (x == 6) {
            this.list = new ArrayList();
            for (Object add222222 : values6) {
                this.list.add(add222222);
            }
        }
        this.day.setText(this.array[x]);
        this.day.setTextColor(-1);
        return new ArrayAdapter(this, 17367043, this.list);
    }

    public void onItemClick(AdapterView<?> adapterView, View arg1, int position, long arg3) {
    }

    public void onClick(View arg0) {
    }

    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case 0:
                this.x1 = event.getX();
                break;
            case 1:
                this.x2 = event.getX();
                if (Math.abs(this.x2 - this.x1) > 100.0f) {
                    if (this.x2 <= this.x1) {
                        this.list.clear();
                        this.f2x++;
                        if (this.f2x > 6) {
                            this.f2x = 0;
                        }
                        this.day.setText(this.f2x);
                        this.adapter = putvalue(this.f2x);
                        this.listview.setAdapter(this.adapter);
                        break;
                    }
                    this.list.clear();
                    this.f2x--;
                    if (this.f2x < 0) {
                        this.f2x = 6;
                    }
                    this.day.setText(this.f2x);
                    this.adapter = putvalue(this.f2x);
                    this.listview.setAdapter(this.adapter);
                    break;
                }
                break;
        }
        return true;
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}
