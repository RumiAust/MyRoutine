package com.aust.dynamic;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class HotOrNot {
    private static final String DATABASE_NAME = "QuizList";
    private static final String DATABASE_TABLE = "Dynamic32";
    private static final int DATABASE_VERSION = 1;
    public static final String KEY_DAY = "quiz_day";
    public static final String KEY_HOUR = "quiz_hour";
    public static final String KEY_MINUTE = "quiz_minute";
    public static final String KEY_MONTH = "quiz_month";
    public static final String KEY_NAME = "quiz_name";
    public static final String KEY_ROWID = "_id";
    public static final String KEY_YEAR = "quiz_year";
    private Context ourContext;
    private SQLiteDatabase ourDatabase;
    private DbHelper ourHelper;

    private static class DbHelper extends SQLiteOpenHelper {
        public DbHelper(Context context) {
            super(context, HotOrNot.DATABASE_NAME, null, 1);
        }

        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE Dynamic32 (_id INTEGER PRIMARY KEY AUTOINCREMENT, quiz_name TEXT NOT NULL, quiz_day INTEGER, quiz_month INTEGER, quiz_year INTEGER, quiz_hour INTEGER, quiz_minute INTEGER);");
        }

        public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
            db.execSQL(" DROP TABLE IF EXISTS Dynamic32");
            onCreate(db);
        }
    }

    public HotOrNot(Context c) {
        this.ourContext = c;
    }

    public HotOrNot open() throws SQLException {
        this.ourHelper = new DbHelper(this.ourContext);
        this.ourDatabase = this.ourHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        this.ourHelper.close();
    }

    public long createEntry(String name, int day, int month, int year, int hour, int minute) throws SQLException {
        ContentValues cv = new ContentValues();
        cv.put(KEY_NAME, name);
        cv.put(KEY_DAY, Integer.valueOf(day));
        cv.put(KEY_MONTH, Integer.valueOf(month));
        cv.put(KEY_YEAR, Integer.valueOf(year));
        cv.put(KEY_HOUR, Integer.valueOf(hour));
        cv.put(KEY_MINUTE, Integer.valueOf(minute));
        return this.ourDatabase.insert(DATABASE_TABLE, null, cv);
    }

    public String getData() throws SQLException {
        Cursor c = this.ourDatabase.query(DATABASE_TABLE, new String[]{KEY_ROWID, KEY_NAME, KEY_DAY, KEY_MONTH, KEY_YEAR, KEY_HOUR, KEY_MINUTE}, null, null, null, null, null);
        String result = "";
        int iRow = c.getColumnIndex(KEY_ROWID);
        int iName = c.getColumnIndex(KEY_NAME);
        int iDay = c.getColumnIndex(KEY_DAY);
        int iMonth = c.getColumnIndex(KEY_MONTH);
        int iYear = c.getColumnIndex(KEY_YEAR);
        int iHour = c.getColumnIndex(KEY_HOUR);
        int iMinute = c.getColumnIndex(KEY_MINUTE);
        c.moveToFirst();
        while (!c.isAfterLast()) {
            result = new StringBuilder(String.valueOf(result)).append(c.getString(iRow)).append(". ").append(c.getString(iName)).append("       ---  ").append(c.getString(iDay)).append("-").append(c.getString(iMonth)).append("-").append(c.getString(iYear)).append(" \t ").append(c.getString(iHour)).append(":").append(c.getString(iMinute)).append(" ").append("\n").toString();
            c.moveToNext();
        }
        return result;
    }

    public void updateEntry(long lRow, String name, int day, int month, int year, int hour, int minute) throws SQLException {
        ContentValues cvUpdate = new ContentValues();
        cvUpdate.put(KEY_NAME, name);
        cvUpdate.put(KEY_DAY, Integer.valueOf(day));
        cvUpdate.put(KEY_MONTH, Integer.valueOf(month));
        cvUpdate.put(KEY_YEAR, Integer.valueOf(year));
        cvUpdate.put(KEY_HOUR, Integer.valueOf(hour));
        cvUpdate.put(KEY_MINUTE, Integer.valueOf(minute));
        this.ourDatabase.update(DATABASE_TABLE, cvUpdate, "_id=" + lRow, null);
    }

    public void updateEntry(long lRow1) throws SQLException {
        this.ourDatabase.delete(DATABASE_TABLE, "_id=" + lRow1, null);
    }
}
