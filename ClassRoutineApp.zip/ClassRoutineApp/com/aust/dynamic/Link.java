package com.aust.dynamic;

import android.app.Activity;
import android.os.Bundle;

public class Link extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0040R.layout.don);
    }
}
