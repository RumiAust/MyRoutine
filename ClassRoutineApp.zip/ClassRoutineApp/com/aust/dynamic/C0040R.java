package com.aust.dynamic;

public final class C0040R {

    public static final class attr {
    }

    public static final class dimen {
        public static final int activity_horizontal_margin = 2130968576;
        public static final int activity_vertical_margin = 2130968577;
    }

    public static final class drawable {
        public static final int back1 = 2130837504;
        public static final int bavk1 = 2130837505;
        public static final int bck = 2130837506;
        public static final int girlie = 2130837507;
        public static final int ic_launcher = 2130837508;
        public static final int image2 = 2130837509;
        public static final int index1 = 2130837510;
        public static final int next = 2130837511;
        public static final int nextbutton = 2130837512;
        public static final int previous = 2130837513;
        public static final int previousbutton = 2130837514;
    }

    public static final class id {
        public static final int about = 2131230750;
        public static final int addQuiz = 2131230748;
        public static final int bDelete = 2131230735;
        public static final int bSave = 2131230733;
        public static final int bUpdate = 2131230734;
        public static final int button1 = 2131230722;
        public static final int button2 = 2131230736;
        public static final int button3 = 2131230743;
        public static final int button4 = 2131230745;
        public static final int button5 = 2131230747;
        public static final int buttonDate = 2131230724;
        public static final int buttonTime = 2131230726;
        public static final int datePicker1 = 2131230729;
        public static final int date_picker = 2131230725;
        public static final int day = 2131230721;
        public static final int editText1 = 2131230731;
        public static final int editText2 = 2131230732;
        public static final int etSubject = 2131230728;
        public static final int listView = 2131230720;
        public static final int tableLayout1 = 2131230738;
        public static final int tableRow1 = 2131230739;
        public static final int tableRow2 = 2131230740;
        public static final int tableRow3 = 2131230741;
        public static final int tableRow4 = 2131230744;
        public static final int tableRow5 = 2131230746;
        public static final int textView1 = 2131230723;
        public static final int textView2 = 2131230742;
        public static final int textView3 = 2131230730;
        public static final int timePicker = 2131230727;
        public static final int tvSqlInfo = 2131230737;
        public static final int viewQuiz = 2131230749;
    }

    public static final class layout {
        public static final int activity_main = 2130903040;
        public static final int don = 2130903041;
        public static final int splash = 2130903042;
        public static final int sqlexample = 2130903043;
        public static final int sqlview = 2130903044;
        public static final int tablelayout = 2130903045;
        public static final int tabmenu = 2130903046;
    }

    public static final class menu {
        public static final int cool_menu = 2131165184;
        public static final int main = 2131165185;
    }

    public static final class string {
        public static final int action_settings = 2131034113;
        public static final int app_name = 2131034112;
        public static final int hello_world = 2131034114;
    }

    public static final class style {
        public static final int AppBaseTheme = 2131099648;
        public static final int AppTheme = 2131099649;
    }
}
